#library(testthat)

#test_package("choroplethrZip")
